BubblePopWorld — Sell Kiosk Mesh Pack (v1)

This pack contains multiple OBJ meshes to help recreate the stylized sell kiosk.
Recommended import workflow in Roblox Studio:
1. Home > Import 3D
2. Import each OBJ as a MeshPart / Model
3. Anchor imported pieces during placement
4. Place them under Workspace.BubblePopWorld.Lobby.SellKioskMeshes or similar
5. Let Cursor / scripts position them, or place them manually in Studio

Files included:
- MainSign.obj               : main rounded sign panel
- RoofCanopy.obj             : layered roof canopy
- KioskColumn.obj            : one stylized support column (duplicate 4x)
- CounterBody.obj            : main front counter body
- FrontDisplayFrame.obj      : trapezoid frame for bag-value display
- BubbleTankBase.obj         : bottom platform for central tank
- BubbleTankTop.obj          : top cap for central tank
- TerminalFrame.obj          : right-side conversion terminal frame
- SellPad.obj                : floor sell pad
- CoinBadge.obj              : circular coin badge decoration
- BubbleDeco.obj             : cluster of decorative bubble meshes

Suggested assembly (approximate):
- RoofCanopy: center at (0, 12, 0)
- MainSign: center at (0, 17.2, -1.0)
- Columns (4x): near corners of canopy, around x ±9.2 and z ±2.8
- CounterBody: center at (0, 4.0, 0.7)
- FrontDisplayFrame: at (0, 3.7, 2.45) embedded in front of counter
- BubbleTankBase: at (-1.4, 6.9, -0.35)
- BubbleTankTop: at (-1.4, 11.15, -0.35)
- TerminalFrame: at (5.5, 7.0, -0.15)
- SellPad: at (0, 0.15, 6.3)
- CoinBadge: attach on left front column or counter side
- BubbleDeco: duplicate as desired around sign or tank

Notes:
- The transparent cylinder of the tank should remain a Roblox Part (Cylinder) or MeshPart created in Studio for easy transparency.
- Text such as 'VENDRE LES BULLES' and the bag-value numbers are best handled with SurfaceGui for crisp rendering.
- Neon borders should remain separate Roblox Parts so colors can be adjusted easily.